create view single_choice_question as
select `cq`.`topic_id`       AS `topic_id`,
       `cq`.`topic_self`     AS `topic_self`,
       `cq`.`topic_type`     AS `topic_type`,
       `cq`.`topic_comment`  AS `topic_comment`,
       `cq`.`option_id`      AS `option_id`,
       `cq`.`option_self`    AS `option_self`,
       `cq`.`is_correct`     AS `is_correct`,
       `cq`.`option_comment` AS `option_comment`
from `exam`.`choice_question` `cq`
where (`cq`.`topic_type` = 1);

-- comment on column single_choice_question.topic_id not supported: 题目ID

-- comment on column single_choice_question.topic_self not supported: 题目本身

-- comment on column single_choice_question.topic_type not supported: 题目类型

-- comment on column single_choice_question.topic_comment not supported: 题目备注

-- comment on column single_choice_question.option_id not supported: 选项Id

-- comment on column single_choice_question.option_self not supported: 选项本身

-- comment on column single_choice_question.is_correct not supported: 该选项是否正确的

-- comment on column single_choice_question.option_comment not supported: 选项备注

