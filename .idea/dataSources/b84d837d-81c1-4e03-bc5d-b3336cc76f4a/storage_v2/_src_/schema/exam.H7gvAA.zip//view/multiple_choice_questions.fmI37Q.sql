create view multiple_choice_questions as
select `choice_question`.`topic_id`       AS `topic_id`,
       `choice_question`.`topic_self`     AS `topic_self`,
       `choice_question`.`topic_type`     AS `topic_type`,
       `choice_question`.`topic_comment`  AS `topic_comment`,
       `choice_question`.`option_id`      AS `option_id`,
       `choice_question`.`option_self`    AS `option_self`,
       `choice_question`.`is_correct`     AS `is_correct`,
       `choice_question`.`option_comment` AS `option_comment`
from `exam`.`choice_question`
where (`choice_question`.`topic_type` = 2);

-- comment on column multiple_choice_questions.topic_id not supported: 题目ID

-- comment on column multiple_choice_questions.topic_self not supported: 题目本身

-- comment on column multiple_choice_questions.topic_type not supported: 题目类型

-- comment on column multiple_choice_questions.topic_comment not supported: 题目备注

-- comment on column multiple_choice_questions.option_id not supported: 选项Id

-- comment on column multiple_choice_questions.option_self not supported: 选项本身

-- comment on column multiple_choice_questions.is_correct not supported: 该选项是否正确的

-- comment on column multiple_choice_questions.option_comment not supported: 选项备注

