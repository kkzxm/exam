create view choice_question as
select `tp`.`topic_id`      AS `topic_id`,
       `tp`.`topic_self`    AS `topic_self`,
       `tp`.`topic_type`    AS `topic_type`,
       `tp`.`topic_comment` AS `topic_comment`,
       `o`.`option_id`      AS `option_id`,
       `o`.`option_self`    AS `option_self`,
       `o`.`is_correct`     AS `is_correct`,
       `o`.`option_comment` AS `option_comment`
from (`exam`.`topic` `tp`
         left join `exam`.`options` `o` on ((`tp`.`topic_id` = `o`.`topic_id`)));

-- comment on column choice_question.topic_id not supported: 题目ID

-- comment on column choice_question.topic_self not supported: 题目本身

-- comment on column choice_question.topic_type not supported: 题目类型

-- comment on column choice_question.topic_comment not supported: 题目备注

-- comment on column choice_question.option_id not supported: 选项Id

-- comment on column choice_question.option_self not supported: 选项本身

-- comment on column choice_question.is_correct not supported: 该选项是否正确的

-- comment on column choice_question.option_comment not supported: 选项备注

