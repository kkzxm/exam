create view answer_info as
select `ans`.`answer_id`      AS `answer_id`,
       `ans`.`answer_self`    AS `answer_self`,
       `ans`.`answer_comment` AS `answer_comment`,
       `ans`.`topic_id`       AS `topic_id`,
       `t`.`topic_self`       AS `topic_self`,
       `t`.`topic_type`       AS `topic_type`,
       `t`.`topic_comment`    AS `topic_comment`
from (`exam`.`answer` `ans`
         left join `exam`.`topic` `t` on ((`t`.`topic_id` = `ans`.`topic_id`)))
where (`t`.`topic_type` = 3);

-- comment on column answer_info.answer_id not supported: 答案Id

-- comment on column answer_info.answer_self not supported: 答案本身

-- comment on column answer_info.answer_comment not supported: 答案备注

-- comment on column answer_info.topic_id not supported: 归属题目(外键)

-- comment on column answer_info.topic_self not supported: 题目本身

-- comment on column answer_info.topic_type not supported: 题目类型

-- comment on column answer_info.topic_comment not supported: 题目备注

